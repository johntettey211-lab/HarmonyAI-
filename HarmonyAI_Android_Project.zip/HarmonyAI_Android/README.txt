HARMONYAI ANDROID STARTER

Your photo is included on the welcome screen.

This starter project opens with the photo, HarmonyAI title, and a START CHATTING button. It includes a basic chat screen, but online AI is not connected yet.

BUILD AN APK:
1. Install Android Studio on your computer.
2. Extract this ZIP.
3. Open the HarmonyAI_Android folder in Android Studio.
4. Allow Gradle sync; install Android SDK 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Choose Locate when the build finishes. The APK is normally in app/build/outputs/apk/debug/.
7. Transfer the APK to your Android phone and tap it to install. Approve Android's install-from-this-source prompt if shown.

SECURITY: Do not put a private OpenAI API key inside an APK. For a real online-AI app, connect through a secure backend that keeps the API key private.

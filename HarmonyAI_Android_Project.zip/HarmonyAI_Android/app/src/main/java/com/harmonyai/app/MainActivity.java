package com.harmonyai.app;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
 int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
 TextView label(String s,int size,int color,boolean bold){
  TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
  if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
 }
 GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
 public void onCreate(Bundle b){super.onCreate(b);welcome();}
 void welcome(){
  FrameLayout root=new FrameLayout(this);
  ImageView photo=new ImageView(this);photo.setImageResource(R.drawable.welcome_photo);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
  root.addView(photo,new FrameLayout.LayoutParams(-1,-1));
  View shade=new View(this);shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x22000000,0xAA07152B,0xE607152B}));
  root.addView(shade,new FrameLayout.LayoutParams(-1,-1));
  LinearLayout content=new LinearLayout(this);content.setOrientation(1);content.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.BOTTOM);content.setPadding(dp(26),dp(20),dp(26),dp(52));
  TextView title=label("HarmonyAI",36,Color.WHITE,true);title.setGravity(Gravity.CENTER);
  TextView sub=label("Your personal AI assistant",17,Color.WHITE,false);sub.setGravity(Gravity.CENTER);
  Button start=new Button(this);start.setText("START CHATTING");start.setAllCaps(false);start.setTextColor(Color.WHITE);start.setBackground(bg(0xFF3157D5,28));start.setOnClickListener(v->chat());
  content.addView(title);content.addView(sub);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.topMargin=dp(24);content.addView(start,p);
  root.addView(content,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));setContentView(root);
 }
 void chat(){
  LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(0xFFF4F6FB);
  TextView header=label("HarmonyAI",22,Color.WHITE,true);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(18),0,0,0);header.setBackgroundColor(0xFF182B55);root.addView(header,new LinearLayout.LayoutParams(-1,dp(58)));
  ScrollView scroll=new ScrollView(this);LinearLayout messages=new LinearLayout(this);messages.setOrientation(1);messages.setPadding(dp(14),dp(14),dp(14),dp(14));
  TextView intro=label("Hello! I'm HarmonyAI. Your welcome screen is ready. Online AI will be connected after API setup.",16,0xFF202536,false);intro.setPadding(dp(12),dp(10),dp(12),dp(10));intro.setBackground(bg(Color.WHITE,14));messages.addView(intro);scroll.addView(messages);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout bar=new LinearLayout(this);bar.setPadding(dp(8),dp(6),dp(8),dp(6));bar.setBackgroundColor(Color.WHITE);
  EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Type your message...");bar.addView(input,new LinearLayout.LayoutParams(0,dp(52),1));
  Button send=new Button(this);send.setText("Send");send.setAllCaps(false);send.setOnClickListener(v->{String s=input.getText().toString().trim();if(!s.isEmpty()){
   TextView u=label("You: "+s,15,0xFF182B55,true);u.setPadding(dp(10),dp(9),dp(10),dp(9));u.setBackground(bg(0xFFDDE7FF,12));LinearLayout.LayoutParams up=new LinearLayout.LayoutParams(-1,-2);up.topMargin=dp(8);messages.addView(u,up);
   TextView r=label("HarmonyAI: Online AI is not connected yet. We'll connect it after your API setup.",15,0xFF202536,false);r.setPadding(dp(10),dp(9),dp(10),dp(9));r.setBackground(bg(Color.WHITE,12));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(7);messages.addView(r,rp);input.setText("");scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
  }});bar.addView(send);root.addView(bar);setContentView(root);
 }
}
